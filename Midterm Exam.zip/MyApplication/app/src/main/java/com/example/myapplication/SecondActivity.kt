package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {

    override fun onStart() {
        super.onStart()
        Log.d("ActivityLifecycle", "activity 2 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLifecycle", "activity 2 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ActivityLifecycle", "activity 2 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("ActivityLifecycle", "activity 2 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ActivityLifecycle", "activity 2 has stopped")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val inputFromFirst = intent.getStringExtra("user_input") ?: ""
        val displayText = findViewById<TextView>(R.id.textViewSecond)
        val button = findViewById<Button>(R.id.buttonToThird)

        displayText.text = inputFromFirst

        button.setOnClickListener {
            val intent = Intent(this, ThirdActivity::class.java)
            intent.putExtra("second_input", inputFromFirst)
            startActivity(intent)
        }
    }
}