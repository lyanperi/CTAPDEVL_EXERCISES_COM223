package com.example.myapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri

class ThirdActivity : AppCompatActivity() {

    override fun onStart() {
        super.onStart()
        Log.d("ActivityLifecycle", "activity 3 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLifecycle", "activity 3 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ActivityLifecycle", "activity 3 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("ActivityLifecycle", "activity 3 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ActivityLifecycle", "activity 3 has stopped")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val inputFromSecond = intent.getStringExtra("second_input") ?: ""
        val displayText = findViewById<TextView>(R.id.textViewThird)
        val githubButton = findViewById<Button>(R.id.githubButton)

        displayText.text = inputFromSecond

        githubButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, "https://github.com/lyanperi".toUri())
            startActivity(intent)
        }
    }
}