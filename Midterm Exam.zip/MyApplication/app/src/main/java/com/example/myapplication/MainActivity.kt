package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onStart() {
        super.onStart()
        Log.d("ActivityLifecycle", "activity 1 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("ActivityLifecycle", "activity 1 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("ActivityLifecycle", "activity 1 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("ActivityLifecycle", "activity 1 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ActivityLifecycle", "activity 1 has stopped")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.buttonToSecond)
        val input = findViewById<EditText>(R.id.editText)

        button.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("user_input", input.text.toString())
            startActivity(intent)
        }
    }
}